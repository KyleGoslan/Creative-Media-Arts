import UIKit
import CoreLocation
import MapKit

class ViewController: UIViewController {
  
  @IBOutlet weak var mapView: MKMapView!
  
  let locationManager = CLLocationManager()
  
  override func viewDidLoad() {
    super.viewDidLoad()
    
    locationManager.requestAlwaysAuthorization()
    locationManager.delegate = self
    locationManager.startUpdatingLocation()
    
    mapView.userTrackingMode = .follow
  
  }
  
}

extension ViewController: CLLocationManagerDelegate {


}







